# birdsland/forms.py

from django import forms
from django.contrib.auth.models import User
from birdsland.models import UserProfileInfo, Post

class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta():
        model = UserProfileInfo
        fields = ('username','password','email')
class PostForm(forms.ModelForm):
    class Meta():
        model = Post
        fields = ('title','slug','body', 'publish', 'status')
