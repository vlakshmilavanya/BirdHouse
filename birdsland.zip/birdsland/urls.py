from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('user_login',views.user_login,name='user_login'),
	path('welcome',views.welcome,name='welcome'),
	path('user_logout',views.user_logout,name='user_logout'),
	path('register',views.register,name='register'),
        path('dropdown',views.dropdown,name='dropdown'),
	path('birds' ,views.birds,name='birds'),
	path('products' ,views.products,name='products'),
	path('blog' ,views.blog,name='blog'),
	path('home' ,views.home,name='home'),
        path('post' ,views.post,name='post'),

]
# birdsland/urls.py



# SET THE NAMESPACE!

# Be careful setting the name to just /login use userlogin instead

