# Create your views here.
from django.shortcuts import render
from birdsland.forms import UserForm, PostForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from birdsland.models import UserProfileInfo, Post

def index(request):
	return render(request, 'index.html')
# birdsland/views.py

def user_logout(request):
    logout(request)
    return render(request, 'index.html')

def welcome(request):
	return render(request, 'welcome.html')

def dropdown(request):
        return render(request, 'dropdown.html')

def birds(request):
	return render(request, 'birds.html')

def products(request):
	return render(request, 'products.html')

def home(request):
	return render(request, 'home.html')

def blog(request):
    registered = False
    if request.method == 'POST':
        post_form = PostForm(data=request.POST)
       
        if post_form.is_valid():
            user = post_form.save()
            #user.set_password(user.password)
            user.save()
            registered = True
            return render(request,'post.html',{'post_form':post_form,'registered':registered})
        else:
            print(post_form.errors)
    else:
        post_form = PostForm()
    return render(request,'blog.html',{'post_form':post_form,'registered':registered})

def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
       
        if user_form.is_valid():
            user = user_form.save()
            #user.set_password(user.password)
            user.save()
            registered = True
            return render(request,'welcome.html',{'user_form':user_form,'registered':registered})
        else:
            #print(user_form.errors)
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid registration")
    else:
        user_form = UserForm()
    return render(request,'register.html',{'user_form':user_form,'registered':registered})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        a = UserProfileInfo.objects.filter(username=username).exists()
        b = UserProfileInfo.objects.filter(password=password).exists()
        if a and b:
             return HttpResponseRedirect(reverse('welcome'))
           # else:
            #    return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'user_login.html')


def post(request):
	allblogs= Post.objects.all()
	context= {'allblogs': allblogs}
	return render(request, 'post.html', context)



