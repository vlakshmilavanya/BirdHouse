# birdsland/admin.py

from django.contrib import admin
from birdsland.models import UserProfileInfo
admin.site.register(UserProfileInfo)

from .models import Post

admin.site.register(Post)

